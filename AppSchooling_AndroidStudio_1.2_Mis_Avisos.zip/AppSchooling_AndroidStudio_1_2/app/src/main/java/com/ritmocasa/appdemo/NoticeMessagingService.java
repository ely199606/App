package com.ritmocasa.appdemo;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Internal SDK entry point. Administrative sends must use canonical data-only messages. */
public final class NoticeMessagingService extends FirebaseMessagingService {
    @Override public void onMessageReceived(RemoteMessage message) {
        if (!NoticeRuntime.optedIn(this)) return;
        NoticeRecord notice = NoticeStore.fromData(message.getData());
        if (notice == null || !NoticeStore.upsert(this, notice)) return;
        NoticeRuntime.noticeChanged(notice.id);
        if (!NoticeRuntime.foreground()) NoticeNotifier.show(this, notice);
    }

    @Override public void onNewToken(String token) {
        // The token stays inside the app/SDK; no student data or token is exposed to the WebView.
        NoticeRuntime.refreshToken(this, token);
    }
}
