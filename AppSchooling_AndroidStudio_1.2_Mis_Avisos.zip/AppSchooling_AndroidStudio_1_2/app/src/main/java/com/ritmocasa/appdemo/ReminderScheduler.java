package com.ritmocasa.appdemo;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import java.util.Calendar;

/** Local, intentionally inexact reminders; no internet and no cloud push. */
public final class ReminderScheduler {
    static final String PREF="ritmo_reminders",CHANNEL="rhythm_care";
    static final String[] KEYS={"study","water","rest"};
    private static final int[] CODES={101,102,103};
    private static final String[] TITLES={"Comenzar con calma","Una pausa de autocuidado","Cierre amable de la jornada"};
    private static final String[] BODIES={
        "¿Qué pequeño paso te gustaría intentar?",
        "Si lo necesitas, descansa o bebe un poco de agua.",
        "¿Qué te ayudó a aprender hoy?"
    };
    private ReminderScheduler(){}
    static void ensureChannel(Context c){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null && Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(
            new NotificationChannel(CHANNEL,"Recordatorios suaves",NotificationManager.IMPORTANCE_LOW));
    }
    static void saveAndSchedule(Context c,boolean enabled,String study,String water,String rest){
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putBoolean("enabled",enabled)
            .putString("study",study).putString("water",water).putString("rest",rest).apply();
        reschedule(c);
    }
    static void reschedule(Context c){
        SharedPreferences p=c.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        boolean enabled=p.getBoolean("enabled",false);
        AlarmManager alarms=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(alarms==null)return;
        for(int i=0;i<KEYS.length;i++){
            Intent intent=new Intent(c,ReminderReceiver.class).putExtra("index",i);
            PendingIntent pi=PendingIntent.getBroadcast(c,CODES[i],intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            alarms.cancel(pi);
            if(!enabled)continue;
            String val=p.getString(KEYS[i],new String[]{"10:00","12:00","17:00"}[i]);
            if(val==null||!val.matches("[0-2][0-9]:[0-5][0-9]"))continue;
            String[] parts=val.split(":");int hr=Integer.parseInt(parts[0]),min=Integer.parseInt(parts[1]);
            if(hr>23)continue;
            Calendar next=Calendar.getInstance();next.set(Calendar.HOUR_OF_DAY,hr);next.set(Calendar.MINUTE,min);
            next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);
            if(next.getTimeInMillis()<=System.currentTimeMillis())next.add(Calendar.DAY_OF_YEAR,1);
            alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);
        }
    }
    static void show(Context c,String title,String body,int id){
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        ensureChannel(c);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        Intent i=new Intent(c,MainActivity.class);
        PendingIntent open=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf).setContentTitle(title).setContentText(body)
            .setAutoCancel(true).setContentIntent(open).build();
        nm.notify(id,n);
    }
    static String title(int n){return TITLES[n];}
    static String body(int n){return BODIES[n];}
}
