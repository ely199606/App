package com.ritmocasa.appdemo;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONException;
import org.json.JSONObject;
import java.lang.ref.WeakReference;

/** Opt-in registration and a process-local UI signal; no administrator credentials are stored here. */
final class NoticeRuntime {
    private static final String PREF = "manzanin_notice_registration_v1";
    private static final String PUBLIC_TOPIC = "avisos_generales";
    private static WeakReference<Listener> listener = new WeakReference<>(null);
    private static volatile boolean foreground;
    private static boolean registering;
    interface Listener {
        void onNoticeChanged(String id);
        void onNoticeStatusChanged();
    }
    private NoticeRuntime() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static void attach(Listener value) { listener = new WeakReference<>(value); }
    static void detach(Listener value) { if (listener.get() == value) listener.clear(); }
    static void setForeground(boolean value) { foreground = value; }
    static boolean foreground() { return foreground; }
    static boolean optedIn(Context c) { return prefs(c).getBoolean("optIn", false); }
    static void noticeChanged(String id) { Listener value = listener.get(); if (value != null) value.onNoticeChanged(id); }
    static void statusChanged() { Listener value = listener.get(); if (value != null) value.onNoticeStatusChanged(); }

    static boolean configured(Context c) {
        try {
            FirebaseApp app = FirebaseApp.initializeApp(c.getApplicationContext());
            if (app == null) return false;
            FirebaseOptions options = app.getOptions();
            return nonEmpty(options.getApplicationId()) && nonEmpty(options.getApiKey())
                && nonEmpty(options.getProjectId()) && nonEmpty(options.getGcmSenderId());
        } catch (RuntimeException unavailable) { return false; }
    }

    static void initialize(Context c) {
        NoticeNotifier.ensureChannel(c);
        if (configured(c) && optedIn(c) && NoticeNotifier.permissionGranted(c)) register(c);
    }

    static void setOptIn(Context c) {
        prefs(c).edit().putBoolean("optIn", true).apply();
    }

    static void permissionAsked(Context c) {
        prefs(c).edit().putBoolean("permissionAsked", true).apply();
    }

    static JSONObject status(Context c) {
        JSONObject result = new JSONObject();
        boolean configured = configured(c);
        boolean permission = NoticeNotifier.permissionGranted(c);
        String registration = configured ? prefs(c).getString("registration", "inactive") : "inactive";
        if (!optedIn(c)) registration = "inactive";
        try {
            result.put("configured", configured)
                .put("permission", permission ? "granted" : prefs(c).getBoolean("permissionAsked", false) ? "denied" : "notDetermined")
                .put("registration", registration)
                .put("enabled", configured && permission && NoticeNotifier.enabled(c) && "ready".equals(registration));
        } catch (JSONException ignored) { /* All values are primitive. */ }
        return result;
    }

    static synchronized void register(Context context) {
        final Context c = context.getApplicationContext();
        if (registering || !optedIn(c) || !NoticeNotifier.permissionGranted(c) || !configured(c)) {
            statusChanged();
            return;
        }
        registering = true;
        setRegistration(c, "pending");
        try {
            FirebaseMessaging messaging = FirebaseMessaging.getInstance();
            messaging.setAutoInitEnabled(true);
            messaging.getToken().addOnSuccessListener(token -> {
                if (!optedIn(c) || !NoticeNotifier.permissionGranted(c)) {
                    finishRegistration(c, false, "inactive");
                    return;
                }
                prefs(c).edit().putString("token", token).apply();
                messaging.subscribeToTopic(PUBLIC_TOPIC)
                    .addOnSuccessListener(unused -> finishRegistration(c, true, "ready"))
                    .addOnFailureListener(error -> finishRegistration(c, false, "error"));
            }).addOnFailureListener(error -> finishRegistration(c, false, "error"));
        } catch (RuntimeException failure) { finishRegistration(c, false, "error"); }
    }

    static void refreshToken(Context c, String token) {
        if (!optedIn(c) || token == null || token.isEmpty()) return;
        prefs(c).edit().putString("token", token).putString("registration", "pending").apply();
        register(c);
    }

    private static synchronized void finishRegistration(Context c, boolean success, String state) {
        registering = false;
        if (success && (!optedIn(c) || !NoticeNotifier.permissionGranted(c))) state = "inactive";
        setRegistration(c, state);
    }

    private static void setRegistration(Context c, String state) {
        prefs(c).edit().putString("registration", state).apply();
        statusChanged();
    }

    private static boolean nonEmpty(String value) { return value != null && !value.trim().isEmpty(); }
}
