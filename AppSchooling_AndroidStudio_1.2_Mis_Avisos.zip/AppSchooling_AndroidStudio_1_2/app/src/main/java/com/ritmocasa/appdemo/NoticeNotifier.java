package com.ritmocasa.appdemo;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

final class NoticeNotifier {
    static final String CHANNEL = "manzanin_avisos";
    static final String EXTRA_ID = "manzanin_notice_id";
    private NoticeNotifier() {}

    static void ensureChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Avisos de la academia", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Evaluaciones, inscripciones y comunicaciones para la familia");
            nm.createNotificationChannel(channel);
        }
    }

    static boolean permissionGranted(Context c) {
        if (Build.VERSION.SDK_INT >= 33)
            return c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        return nm != null && nm.areNotificationsEnabled();
    }

    static boolean enabled(Context c) {
        if (!permissionGranted(c)) return false;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || !nm.areNotificationsEnabled()) return false;
        NotificationChannel channel = nm.getNotificationChannel(CHANNEL);
        return channel != null && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
    }

    static void show(Context c, NoticeRecord notice) {
        if (notice == null || notice.isExpired(System.currentTimeMillis())) return;
        ensureChannel(c);
        if (!enabled(c)) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        Intent open = new Intent(c, MainActivity.class)
            .setData(new Uri.Builder().scheme("appschooling").authority("avisos").appendPath(notice.id).build())
            .putExtra(EXTRA_ID, notice.id)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new Notification.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf).setContentTitle(notice.title).setContentText(notice.body)
            .setStyle(new Notification.BigTextStyle().bigText(notice.body))
            .setAutoCancel(true).setContentIntent(pi).build();
        // A string tag prevents collisions between different notice identifiers.
        try { nm.notify("notice:" + notice.id, 0, notification); }
        catch (SecurityException permissionChanged) { /* The inbox remains saved. */ }
    }
}
