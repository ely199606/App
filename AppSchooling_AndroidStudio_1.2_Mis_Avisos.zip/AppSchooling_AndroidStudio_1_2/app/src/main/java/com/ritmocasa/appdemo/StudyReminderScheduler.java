package com.ritmocasa.appdemo;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

/** Preserves 1.1's personal study reminders separately from remote academy notices. */
final class StudyReminderScheduler {
    private static final int MAX_REMINDERS = 300;
    private StudyReminderScheduler() {}
    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(ReminderScheduler.PREF, Context.MODE_PRIVATE);
    }
    private static JSONArray read(Context c) {
        try { return new JSONArray(prefs(c).getString("custom", "[]")); }
        catch (JSONException | ClassCastException invalid) { return new JSONArray(); }
    }
    static boolean save(Context c, String json) {
        try {
            JSONArray input = new JSONArray(json), cleaned = new JSONArray();
            if (input.length() > MAX_REMINDERS) return false;
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < input.length(); i++) {
                JSONObject row = input.optJSONObject(i);
                if (row == null) return false;
                Object rawId = row.opt("id"), rawTitle = row.opt("title"), rawAt = row.opt("at");
                if (!(rawId instanceof String) || !(rawTitle instanceof String) || !(rawAt instanceof Number)) return false;
                String id = ((String) rawId).trim(), title = ((String) rawTitle).trim();
                double at = ((Number) rawAt).doubleValue();
                if (id.isEmpty() || id.length() > 200 || title.isEmpty() || title.length() > 90
                        || !Double.isFinite(at) || at != Math.rint(at) || at > Long.MAX_VALUE) return false;
                if (!seen.add(id) || at <= System.currentTimeMillis()) continue;
                JSONObject next = new JSONObject();
                next.put("id", id).put("title", title).put("at", (long) at);
                cleaned.put(next);
            }
            AlarmManager alarms = c.getSystemService(AlarmManager.class);
            if (alarms == null) return false;
            JSONArray old = read(c);
            if (!prefs(c).edit().putString("custom", cleaned.toString()).commit()) return false;
            for (int i = 0; i < old.length(); i++) {
                JSONObject row = old.optJSONObject(i);
                if (row != null) alarms.cancel(pending(c, row));
            }
            schedule(c, cleaned);
            return cleaned.length() > 0;
        } catch (JSONException | SecurityException invalid) { return false; }
    }
    static void reschedule(Context c) { schedule(c, read(c)); }
    private static void schedule(Context c, JSONArray rows) {
        AlarmManager alarms = c.getSystemService(AlarmManager.class);
        if (alarms == null) return;
        for (int i = 0; i < Math.min(rows.length(), MAX_REMINDERS); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            long at = row.optLong("at", 0);
            if (at > System.currentTimeMillis())
                alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(c, row));
        }
    }
    private static PendingIntent pending(Context c, JSONObject row) {
        Intent intent = new Intent(c, ReminderReceiver.class)
            .setData(new Uri.Builder().scheme("appschooling").authority("study").appendPath(row.optString("id")).build())
            .putExtra("custom_title", row.optString("title"));
        return PendingIntent.getBroadcast(c, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
