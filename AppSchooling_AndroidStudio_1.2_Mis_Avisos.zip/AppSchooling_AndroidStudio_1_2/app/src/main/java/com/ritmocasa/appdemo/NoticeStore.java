package com.ritmocasa.appdemo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Device inbox, independent of student profiles. Only the internal FCM service writes content. */
final class NoticeStore {
    private static final String PREF = "manzanin_notices_v1";
    private static final String KEY = "notices";
    private static final int MAX_NOTICES = 500;
    private NoticeStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static synchronized JSONArray all(Context c) {
        try { return new JSONArray(prefs(c).getString(KEY, "[]")); }
        catch (JSONException | ClassCastException invalid) { return new JSONArray(); }
    }

    static synchronized JSONObject find(Context c, String id) {
        if (id == null) return null;
        JSONArray notices = all(c);
        for (int i = 0; i < notices.length(); i++) {
            JSONObject row = notices.optJSONObject(i);
            if (row != null && id.equals(row.optString("id", ""))) return row;
        }
        return null;
    }

    /** Synchronous commit is intentional: a tray notification is never shown before persistence. */
    static synchronized boolean upsert(Context c, NoticeRecord notice) {
        if (notice == null) return false;
        JSONArray old = all(c);
        List<JSONObject> rows = new ArrayList<>();
        for (int i = 0; i < old.length(); i++) {
            JSONObject row = old.optJSONObject(i);
            if (row == null) continue;
            if (notice.id.equals(row.optString("id", ""))) {
                if (row.optInt("revision", 0) >= notice.revision) return false;
            } else rows.add(row);
        }
        JSONObject current = json(notice);
        // A changed deadline or evaluation is new information. The new revision is unread.
        rows.add(current);
        Collections.sort(rows, (a, b) -> Long.compare(epoch(b.optString("publishedAt")), epoch(a.optString("publishedAt"))));
        JSONArray result = new JSONArray();
        for (int i = 0; i < Math.min(MAX_NOTICES, rows.size()); i++) result.put(rows.get(i));
        return prefs(c).edit().putString(KEY, result.toString()).commit();
    }

    static synchronized void markRead(Context c, String id) {
        updateRead(c, id, false);
    }

    static synchronized void markAllRead(Context c) {
        updateRead(c, null, true);
    }

    private static void updateRead(Context c, String id, boolean all) {
        JSONArray rows = all(c);
        boolean changed = false;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null || !(all || (id != null && id.equals(row.optString("id"))))) continue;
            if (row.isNull("readAt") || row.optString("readAt", "").isEmpty()) {
                try { row.put("readAt", Instant.now().toString()); changed = true; }
                catch (JSONException ignored) { /* Retain the previous inbox if an entry fails. */ }
            }
        }
        if (changed) prefs(c).edit().putString(KEY, rows.toString()).commit();
    }

    static JSONObject json(NoticeRecord n) {
        JSONObject row = new JSONObject();
        try {
            row.put("schemaVersion", 1).put("id", n.id).put("revision", n.revision)
                .put("category", n.category).put("title", n.title).put("body", n.body)
                .put("publishedAt", n.publishedAt)
                .put("eventAt", n.eventAt == null ? JSONObject.NULL : n.eventAt)
                .put("expiresAt", n.expiresAt == null ? JSONObject.NULL : n.expiresAt)
                .put("url", n.url == null ? JSONObject.NULL : n.url).put("readAt", JSONObject.NULL);
        } catch (JSONException impossible) { /* Known keys and valid strings only. */ }
        return row;
    }

    /** FCM custom data is either flat string fields or one canonical JSON payload field. */
    static NoticeRecord fromData(Map<String, String> data) {
        if (data == null) return null;
        String payload = data.get("payload");
        if (payload == null) return NoticeRecord.fromMap(data);
        if (payload.length() > 20_000) return null;
        try {
            JSONObject input = new JSONObject(payload);
            Map<String, String> fields = new HashMap<>();
            for (String key : new String[]{"schemaVersion", "revision"}) {
                Object value = input.opt(key);
                if (!(value instanceof Integer || value instanceof Long)) return null;
                fields.put(key, value.toString());
            }
            for (String key : new String[]{"id", "category", "title", "body", "publishedAt", "eventAt", "expiresAt", "url"}) {
                Object value = input.opt(key);
                if (value == null || value == JSONObject.NULL) fields.put(key, null);
                else if (value instanceof String) fields.put(key, (String) value);
                else return null;
            }
            return NoticeRecord.fromMap(fields);
        } catch (JSONException invalid) { return null; }
    }

    private static long epoch(String value) {
        try { return java.time.OffsetDateTime.parse(value).toInstant().toEpochMilli(); }
        catch (RuntimeException invalid) { return Long.MIN_VALUE; }
    }
}
