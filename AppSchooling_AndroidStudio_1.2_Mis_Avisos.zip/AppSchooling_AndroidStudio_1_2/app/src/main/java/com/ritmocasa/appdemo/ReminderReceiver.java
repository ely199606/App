package com.ritmocasa.appdemo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if (intent == null) return;
        if (intent.getData() != null && "appschooling".equals(intent.getData().getScheme())
                && "study".equals(intent.getData().getHost())) {
            String title = intent.getStringExtra("custom_title");
            if (title != null && !title.trim().isEmpty() && title.length() <= 90)
                ReminderScheduler.show(context, "Mi recordatorio", title, intent.getData().toString().hashCode());
            return;
        }
        int n=intent.getIntExtra("index",-1);
        if(n>=0 && n<3) ReminderScheduler.show(context,ReminderScheduler.title(n),ReminderScheduler.body(n),101+n);
    }
}
