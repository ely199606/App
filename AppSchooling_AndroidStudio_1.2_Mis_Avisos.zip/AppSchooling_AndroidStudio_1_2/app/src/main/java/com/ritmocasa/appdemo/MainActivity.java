package com.ritmocasa.appdemo;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Local UI with an opt-in, native notification transport. Remote pages never receive its bridge. */
public class MainActivity extends Activity implements NoticeRuntime.Listener {
    private static final String BASE = "https://appassets.androidplatform.net/assets/www/";
    private static final int PICK_FILE = 300;
    private static final int SAVE_FILE = 301;
    private static final int NOTIFY_PERMISSION = 302;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String backupContent;
    private boolean webReady;
    private String pendingNoticeId;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ReminderScheduler.ensureChannel(this);
        NoticeRuntime.attach(this);
        NoticeRuntime.initialize(this);
        StudyReminderScheduler.reschedule(this);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web = new WebView(this);
        setContentView(web);
        // Preserve the 1.1 APK's system-bar clearance on Android 15 and earlier devices.
        web.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        });
        web.requestApplyInsets();
        WebSettings cfg = web.getSettings();
        cfg.setJavaScriptEnabled(true);
        cfg.setDomStorageEnabled(true);
        cfg.setAllowFileAccess(false);
        cfg.setAllowContentAccess(false);
        cfg.setBlockNetworkLoads(true);
        cfg.setJavaScriptCanOpenWindowsAutomatically(false);
        cfg.setSupportMultipleWindows(false);
        cfg.setMediaPlaybackRequiresUserGesture(true);
        cfg.setUserAgentString(cfg.getUserAgentString() + " AppSchoolingAndroid/1.2");
        web.addJavascriptInterface(new NativeBridge(), "AppSchoolingNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                webReady = false;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return handleNavigation(req.getUrl(), req.isForMainFrame(), req.hasGesture());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url == null || !url.startsWith(BASE)) return;
                webReady = true;
                // A message may arrive while the local scripts are still loading.
                view.evaluateJavascript("if(window.AppSchoolingAvisos){window.AppSchoolingAvisos.syncNative();}", null);
                onNoticeStatusChanged();
                deliverPendingNotice();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] accept=params.getAcceptTypes();
                i.setType(accept!=null && accept.length>0 && accept[0]!=null && !accept[0].isEmpty() ? accept[0] : "*/*");
                try { startActivityForResult(Intent.createChooser(i,"Seleccionar copia de AppSchooling"), PICK_FILE); }
                catch (Exception e) {fileCallback.onReceiveValue(null); fileCallback=null;return false;}
                return true;
            }
        });
        web.clearCache(true); // Cache only; local profiles and notices are retained.
        cfg.setCacheMode(WebSettings.LOAD_NO_CACHE);
        captureNoticeIntent(getIntent());
        web.loadUrl(BASE + "index.html?build=12");
    }

    private boolean handleNavigation(Uri uri, boolean mainFrame, boolean userGesture) {
        if (uri.toString().startsWith(BASE)) return false;
        // Official help and dialing leave the local WebView only after a tap.
        // Remote pages never receive the app's JavaScript bridge.
        if (!mainFrame || !userGesture) return true;
        Intent intent;
        String host = uri.getHost();
        if ("https".equalsIgnoreCase(uri.getScheme())
                && ("ayudamineduc.cl".equalsIgnoreCase(host)
                    || "www.ayudamineduc.cl".equalsIgnoreCase(host)
                    || "inscripcionexameneslibres.mineduc.cl".equalsIgnoreCase(host)
                    || "epja.mineduc.cl".equalsIgnoreCase(host))
                && uri.getUserInfo() == null
                && (uri.getPort() == -1 || uri.getPort() == 443)) {
            intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
        } else if ("tel:6006002626".equals(uri.toString())
                || "tel:+56223536750".equals(uri.toString())) {
            intent = new Intent(Intent.ACTION_DIAL, uri);
        } else {
            return true;
        }
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "No hay una aplicación disponible para abrir este enlace.",
                    Toast.LENGTH_LONG).show();
        }
        return true;
    }

    public final class NativeBridge {
        @JavascriptInterface public String getNotices() {
            return NoticeStore.all(MainActivity.this).toString();
        }
        @JavascriptInterface public String getNoticeStatus() {
            return NoticeRuntime.status(MainActivity.this).toString();
        }
        @JavascriptInterface public void requestNoticePermission() {
            runOnUiThread(() -> {
                if (!NoticeRuntime.configured(MainActivity.this)) {
                    onNoticeStatusChanged();
                    return;
                }
                NoticeRuntime.setOptIn(MainActivity.this);
                if (NoticeNotifier.permissionGranted(MainActivity.this)) NoticeRuntime.register(MainActivity.this);
                else if (Build.VERSION.SDK_INT >= 33) askNotificationPermission();
                else openNoticeSettings();
            });
        }
        @JavascriptInterface public void openNoticeSettings() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                try { startActivity(intent); }
                catch (ActivityNotFoundException unavailable) {
                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
                }
            });
        }
        @JavascriptInterface public void markNoticeRead(String id) {
            NoticeStore.markRead(MainActivity.this, id);
        }
        @JavascriptInterface public void markAllNoticesRead() {
            NoticeStore.markAllRead(MainActivity.this);
        }
        @JavascriptInterface public void openNoticeLink(String id) {
            JSONObject stored = NoticeStore.find(MainActivity.this, id);
            if (stored == null) return;
            NoticeRecord notice = NoticeStore.fromData(java.util.Collections.singletonMap("payload", stored.toString()));
            if (notice == null || notice.url == null) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(notice.url));
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                try { startActivity(intent); }
                catch (ActivityNotFoundException unavailable) {
                    Toast.makeText(MainActivity.this, "No hay una aplicación disponible para abrir este enlace.", Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void syncStudyReminders(String json) {
            if (json == null || json.length() > 200_000) return;
            runOnUiThread(() -> {
                if (StudyReminderScheduler.save(MainActivity.this, json)) askNotificationPermission();
            });
        }
        @JavascriptInterface public void applyReminders(boolean enabled, String study, String water, String rest) {
            runOnUiThread(() -> {
                ReminderScheduler.saveAndSchedule(MainActivity.this,enabled,study,water,rest);
                if (enabled) askNotificationPermission();
            });
        }
        @JavascriptInterface public void testReminder() {
            runOnUiThread(() -> {
                askNotificationPermission();
                if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
                    ReminderScheduler.show(MainActivity.this,"Un momento para ti","Este es un aviso de prueba de AppSchooling.",900);
            });
        }
        @JavascriptInterface public void exportJson(String content) {
            if (content == null || content.length()>2_000_000) return;
            runOnUiThread(() -> {
                backupContent=content;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.setType("application/json");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.putExtra(Intent.EXTRA_TITLE,"AppSchooling-copia.json");
                try {startActivityForResult(i,SAVE_FILE);} catch(Exception ex){backupContent=null;}
            });
        }
    }
    private void askNotificationPermission(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
            NoticeRuntime.permissionAsked(this);
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFY_PERMISSION);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFY_PERMISSION) {
            NoticeRuntime.permissionAsked(this);
            if (NoticeNotifier.permissionGranted(this)) NoticeRuntime.initialize(this);
            onNoticeStatusChanged();
        }
    }
    @Override protected void onResume() {
        super.onResume();
        NoticeRuntime.setForeground(true);
        NoticeRuntime.initialize(this);
        onNoticeStatusChanged();
    }
    @Override protected void onPause() {
        NoticeRuntime.setForeground(false);
        super.onPause();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureNoticeIntent(intent);
        deliverPendingNotice();
    }
    private void captureNoticeIntent(Intent intent) {
        if (intent == null) return;
        // MainActivity is a public launcher, so Intent extras must never create inbox content.
        // Only identifiers already persisted by the non-exported SDK service can be opened.
        try {
            String id = intent.getStringExtra(NoticeNotifier.EXTRA_ID);
            if (id != null && NoticeStore.find(this, id) != null) pendingNoticeId = id;
        } catch (RuntimeException invalidExtra) { /* Ignore untrusted launcher extras. */ }
    }
    private void deliverPendingNotice() {
        if (!webReady || pendingNoticeId == null) return;
        JSONObject detail = new JSONObject();
        try { detail.put("id", pendingNoticeId); }
        catch (org.json.JSONException impossible) { return; }
        pendingNoticeId = null;
        dispatch("appschooling:notice-open", detail);
    }
    @Override public void onNoticeChanged(String id) {
        runOnUiThread(() -> {
            JSONObject notice = NoticeStore.find(this, id);
            if (notice != null) dispatch("appschooling:notice", notice);
        });
    }
    @Override public void onNoticeStatusChanged() {
        runOnUiThread(() -> dispatch("appschooling:notice-status", NoticeRuntime.status(this)));
    }
    private void dispatch(String event, JSONObject detail) {
        if (!webReady || web == null) return;
        String json = detail.toString().replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
        web.evaluateJavascript("document.dispatchEvent(new CustomEvent(" + JSONObject.quote(event)
            + ",{detail:" + json + "}));", null);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_FILE){
            if(fileCallback!=null)fileCallback.onReceiveValue(resultCode==RESULT_OK && data!=null && data.getData()!=null ? new Uri[]{data.getData()}:null);
            fileCallback=null;
        } else if(requestCode==SAVE_FILE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && backupContent!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out!=null){out.write(backupContent.getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"Copia guardada",Toast.LENGTH_SHORT).show();}
                } catch(Exception ex){Toast.makeText(this,"No se pudo guardar la copia",Toast.LENGTH_SHORT).show();}
            }
            backupContent=null;
        }
    }
    @Override public void onBackPressed(){
        // Single-page app. Android Back closes the keyboard first when present.
        super.onBackPressed();
    }
    @Override protected void onDestroy(){
        NoticeRuntime.detach(this);
        webReady = false;
        if(web!=null){web.destroy();web=null;}
        super.onDestroy();
    }
}
