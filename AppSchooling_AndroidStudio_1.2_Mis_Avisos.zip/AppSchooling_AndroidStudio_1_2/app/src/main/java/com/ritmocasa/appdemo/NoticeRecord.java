package com.ritmocasa.appdemo;

import java.net.URI;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.regex.Pattern;

/** Immutable, validated notice content. This class has no Android dependency. */
final class NoticeRecord {
    private static final Pattern ID = Pattern.compile("[A-Za-z0-9._:-]{1,128}");
    private static final Pattern REVISION = Pattern.compile("[1-9][0-9]{0,9}");
    final int schemaVersion = 1;
    final int revision;
    final String id;
    final String title;
    final String body;
    final String category;
    final String publishedAt;
    final String eventAt;
    final String expiresAt;
    final String url;
    private final Long expiresAtMillis;

    private NoticeRecord(String id, int revision, String title, String body,
            String category, String publishedAt, String eventAt, String expiresAt,
            String url, Long expiresAtMillis) {
        this.id = id;
        this.revision = revision;
        this.title = title;
        this.body = body;
        this.category = category;
        this.publishedAt = publishedAt;
        this.eventAt = eventAt;
        this.expiresAt = expiresAt;
        this.url = url;
        this.expiresAtMillis = expiresAtMillis;
    }

    /** Invalid or unsupported payloads are ignored; callers must not notify them. */
    static NoticeRecord fromMap(Map<String, String> data) {
        if (data == null) return null;
        try {
            for (String value : data.values())
                if (value != null && value.indexOf('\u0000') >= 0) return null;
            if (!"1".equals(data.get("schemaVersion"))) return null;
            String id = clean(data.get("id"));
            String revisionText = data.get("revision");
            if (id == null || !ID.matcher(id).matches()
                    || revisionText == null || !REVISION.matcher(revisionText).matches()) return null;
            int revision = Integer.parseInt(revisionText);
            String title = text(data.get("title"), 120, false);
            String body = text(data.get("body"), 5000, true);
            String category = data.get("category");
            if (title == null || body == null
                    || !("general".equals(category) || "evaluaciones".equals(category)
                    || "examenes".equals(category))) return null;

            String publishedAt = clean(data.get("publishedAt"));
            if (publishedAt == null) return null;
            long publishedMillis = dateMillis(publishedAt);
            String eventAt = optional(data.get("eventAt"));
            String expiresAt = optional(data.get("expiresAt"));
            if (eventAt != null) dateMillis(eventAt);
            Long expiresMillis = expiresAt == null ? null : dateMillis(expiresAt);
            if (expiresMillis != null && expiresMillis <= publishedMillis) return null;

            String url = optional(data.get("url"));
            if (url != null && !safeUrl(url)) return null;
            return new NoticeRecord(id, revision, title, body, category, publishedAt,
                    eventAt, expiresAt, url, expiresMillis);
        } catch (RuntimeException invalid) {
            // Includes malformed dates, numeric overflow and hostile Map implementations.
            return null;
        }
    }

    boolean isExpired(long nowMillis) {
        return expiresAtMillis != null && expiresAtMillis <= nowMillis;
    }

    private static String clean(String value) {
        return value == null ? null : value.trim();
    }

    private static String optional(String value) {
        String clean = clean(value);
        return clean == null || clean.isEmpty() ? null : clean;
    }

    private static String text(String value, int maximum, boolean multiline) {
        if (value == null) return null;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if ((c < 32 || c == 127) && !(multiline && (c == '\n' || c == '\r' || c == '\t')))
                return null;
        }
        String clean = clean(value);
        if (clean.isEmpty() || clean.length() > maximum) return null;
        return clean;
    }

    private static long dateMillis(String value) {
        if (value.length() > 64) throw new IllegalArgumentException("Date too long");
        return OffsetDateTime.parse(value, DateTimeFormatter.ISO_OFFSET_DATE_TIME)
                .toInstant().toEpochMilli();
    }

    private static boolean safeUrl(String value) {
        if (value.length() > 2048) return false;
        for (int i = 0; i < value.length(); i++)
            if (value.charAt(i) <= 32 || value.charAt(i) == 127) return false;
        try {
            URI uri = new URI(value);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.isAbsolute()
                    && !uri.isOpaque() && uri.getHost() != null && !uri.getHost().isEmpty()
                    && uri.getRawUserInfo() == null && (uri.getPort() == -1 || uri.getPort() == 443);
        } catch (Exception invalid) {
            return false;
        }
    }
}
