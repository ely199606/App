# Nota técnica de datos de Manzanín 1.2

Esta nota describe la implementación; no sustituye la política de la academia.

Los perfiles, hábitos, notas y planner siguen en el dispositivo. La exportación
de perfiles conserva su formato y no incorpora la bandeja de comunicaciones.
Los avisos se guardan por separado en el dispositivo, hasta un máximo de 500,
y se marcan como leídos localmente. Una revisión nueva vuelve a aparecer sin leer.
Los archivos musicales elegidos por la familia siguen siendo locales.

La recepción remota requiere configurar el proyecto Firebase real. El registro
de mensajería se activa tras la elección de la familia y el permiso del sistema.
Firebase Cloud Messaging gestiona identificadores de instalación/registro y los
datos técnicos necesarios para entregar mensajes. El código de Manzanín no envía
los perfiles, hábitos, notas ni registros emocionales en ese registro. No se añade
Firebase Analytics. El token no se expone al JavaScript ni se imprime en logs.

Las preferencias nativas y los avisos quedan en el almacenamiento privado Android.
El tema avisos_generales es público para instalaciones inscritas: no implementa
un grupo privado ni autorización por curso. La plataforma posterior tendrá que
resolver el acceso a grupos y su sincronización si se requieren esos envíos.

Los enlaces de avisos validados se abren tras un toque en el navegador externo.
Las páginas remotas no reciben el puente JavaScript de la aplicación.
Las notificaciones locales anteriores conservan su funcionamiento y dependen de
los permisos, la batería y los ajustes del dispositivo.

Sin google-services.json válido, la bandeja muestra configuración pendiente.
No hay mensajes de ejemplo precargados ni fechas oficiales inventadas.
