# Recepción de avisos Android

## Configuración

Paquete Android: `com.appschooling.manzanin.piloto09`.
Canal: `manzanin_avisos`. Tema público: `avisos_generales`.
El archivo real `app/google-services.json` se obtiene de la cuenta Firebase de la
academia. No colocar credenciales de servidor ni claves privadas en esta app.

La primera activación requiere compilar con ese archivo y que la familia active
los avisos. El registro solo queda listo cuando FCM confirma token y suscripción.
La plataforma administrativa y los envíos por grupos privados no se incluyen.

## Mensaje que debe enviar la plataforma posterior

Usar FCM HTTP v1 o Admin SDK desde un entorno autenticado del servidor.
Enviar **data-only**, con prioridad Android `HIGH` cuando corresponde una alerta
visible. No se realiza ningún envío real al abrir este proyecto.
Los campos de `data` pueden ser todos strings, o un único `payload` con JSON:

```json
{
  "message": {
    "topic": "avisos_generales",
    "android": {"priority": "HIGH"},
    "data": {
      "schemaVersion": "1",
      "id": "id-estable-del-aviso",
      "revision": "1",
      "category": "general",
      "title": "Título definido por el administrador",
      "body": "Contenido definido por el administrador",
      "publishedAt": "2026-11-02T12:00:00-03:00"
    }
  }
}
```

Este es un ejemplo de contrato, no una comunicación oficial ni un aviso instalado.
Categorías: `general`, `evaluaciones`, `examenes`. Identificador ASCII de hasta128
caracteres (letras, números, `.`, `_`, `:`, `-`). Revisión entera positiva.
Título máximo120 caracteres, cuerpo máximo5000 caracteres para la bandeja local.
**El mensaje FCM completo debe respetar además el límite de bytes del servicio**;
no interpretar el máximo de texto local como una capacidad garantizada de FCM.

Opcionales: `eventAt`, `expiresAt` (ISO8601 con zona); `url` HTTPS, puerto443 o
predeterminado, sin credenciales. En datos planos omitir los opcionales vacíos.
En `payload`, schemaVersion y revision son números, y opcionales pueden ser null.
expiresAt debe ser posterior a publishedAt. Un mensaje expirado queda como
histórico y no produce una alerta nueva. Una revisión más alta vuelve a quedar
sin leer; duplicados y revisiones antiguas no generan otra alerta.

El servicio no exportado valida, guarda y después muestra la notificación.
Al tocarla solo se abre un identificador ya persistido, nunca se ingiere contenido
desde un Intent externo. El WebView sigue restringido a los recursos locales.

## Alcance y límites

Los mensajes `notification + data` pueden ser manejados directamente por Android
en segundo plano y no pasar por onMessageReceived hasta que se abren; por eso no
son el contrato del receptor persistente de esta versión. Firebase Console no
sustituye automáticamente el futuro emisor data-only de la plataforma.

La entrega depende de conexión, permisos, Google Play services y del dispositivo.
No se garantiza recepción inmediata, ni historial de mensajes que nunca llegaron.
La sincronización de un historial remoto queda para la plataforma posterior.

## Interfaz

Puente AppSchoolingNative: getNotices, getNoticeStatus, requestNoticePermission,
openNoticeSettings, markNoticeRead, markAllNoticesRead, openNoticeLink.
Eventos CustomEvent sobre document: appschooling:notice, appschooling:notice-status,
appschooling:notice-open. Las fechas se presentan en la zona del dispositivo.
