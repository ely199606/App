package com.ritmocasa.appdemo;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

public final class NoticeRecordTest {
    private static int checks;
    private static Map<String, String> valid() {
        Map<String, String> data = new HashMap<>();
        data.put("schemaVersion", "1");
        data.put("id", "academia:aviso-42");
        data.put("revision", "1");
        data.put("title", "Evaluación de lectura");
        data.put("body", "Revisa tu guía.\nPuedes preparar tus preguntas con tu familia.");
        data.put("category", "evaluaciones");
        data.put("publishedAt", "2026-11-02T10:00:00-03:00");
        return data;
    }
    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    private static void reject(String key, String value) {
        Map<String, String> data = valid();
        data.put(key, value);
        check(NoticeRecord.fromMap(data) == null, key + " must reject " + value);
    }
    public static void main(String[] args) {
        NoticeRecord initial = NoticeRecord.fromMap(valid());
        check(initial != null, "ordinary Spanish payload accepts");
        check(initial.schemaVersion == 1 && initial.revision == 1, "version fields");
        check(initial.eventAt == null && initial.expiresAt == null && initial.url == null,
                "missing optional fields stay absent");
        check(!initial.isExpired(Long.MAX_VALUE), "no expiry remains usable");
        check(NoticeRecord.fromMap(null) == null, "null map ignores");
        Map<String, String> trim = valid();
        trim.put("title", "  Materiales de hoy  ");
        trim.put("body", "  ¡A tu ritmo!  ");
        trim.put("eventAt", ""); trim.put("expiresAt", "  "); trim.put("url", "");
        NoticeRecord trimmed = NoticeRecord.fromMap(trim);
        check(trimmed != null && trimmed.title.equals("Materiales de hoy")
                && trimmed.body.equals("¡A tu ritmo!") && trimmed.url == null, "normalizes whitespace");

        for (String schema : new String[]{null, "", "0", "2", "01", "1.0", " 1"}) reject("schemaVersion", schema);
        for (String revision : new String[]{null, "", "0", "-1", "01", "1.0", "1e1", "+1", "2147483648", "99999999999"})
            reject("revision", revision);
        Map<String, String> highest = valid(); highest.put("revision", "2147483647");
        check(NoticeRecord.fromMap(highest) != null, "highest integer revision accepts");
        for (String id : new String[]{null, "", " ", "a/b", "á", "a?b", "a\u0000b", "a".repeat(129)}) reject("id", id);
        for (String category : new String[]{null, "", "evaluacion", "admin", "GENERAL"}) reject("category", category);
        for (String category : new String[]{"general", "evaluaciones", "examenes"}) {
            Map<String, String> data = valid(); data.put("category", category);
            check(NoticeRecord.fromMap(data) != null, "allowed category " + category);
        }
        reject("title", "x".repeat(121)); reject("title", " "); reject("title", "a\nb");
        reject("title", "a\u0000b"); reject("body", "x".repeat(5001)); reject("body", "\u0000");
        reject("title", "\u0000Título"); reject("body", "Texto\u0000"); reject("url", "\u0000https://example.com/");
        reject("body", "a\u0001b");
        Map<String, String> edge = valid(); edge.put("title", "x".repeat(120)); edge.put("body", "x".repeat(5000));
        check(NoticeRecord.fromMap(edge) != null, "maximum content limits accept");
        Map<String, String> plainText = valid(); plainText.put("body", "<script>alert('hola')</script> ; SELECT * FROM datos");
        check(NoticeRecord.fromMap(plainText).body.equals(plainText.get("body")),
                "content is preserved as text; presentation must escape it");

        for (String date : new String[]{null, "", "2026-11-02", "2026-11-02T10:00:00", "2026-02-30T10:00:00Z", "ahora", "2026-11-02T25:00:00Z"})
            reject("publishedAt", date);
        reject("eventAt", "2026-11-03T10:00:00");
        reject("expiresAt", "2026-11-02T12:59:59Z"); reject("expiresAt", "2026-11-02T13:00:00Z");
        Map<String, String> dated = valid(); dated.put("eventAt", "2026-11-04T09:00:00-03:00");
        dated.put("expiresAt", "2026-11-04T12:00:00Z");
        NoticeRecord expiring = NoticeRecord.fromMap(dated);
        long expires = Instant.parse("2026-11-04T12:00:00Z").toEpochMilli();
        check(expiring != null && !expiring.isExpired(expires - 1), "expiry only at boundary");
        check(expiring.isExpired(expires) && expiring.isExpired(expires + 1), "expiry includes boundary");
        for (String url : new String[]{"http://example.com", "javascript:alert(1)", "file:///tmp/x", "//example.com", "https:example.com",
                "https://user:secret@example.com/", "https://example.com:8443/", "https://example.com/a b",
                "https://example.com/a\nb", "https:///missing-host", "https://", "https://example.com/" + "x".repeat(2048)}) reject("url", url);
        for (String url : new String[]{"https://ayudamineduc.cl/", "https://example.com:443/a?tema=gu%C3%ADa#paso",
                "HTTPS://example.com/", "https://[2001:db8::1]/"}) {
            Map<String, String> data = valid(); data.put("url", url);
            check(NoticeRecord.fromMap(data) != null, "valid HTTPS link " + url);
        }
        System.out.println("NoticeRecordTest passed " + checks + " checks");
    }
}
