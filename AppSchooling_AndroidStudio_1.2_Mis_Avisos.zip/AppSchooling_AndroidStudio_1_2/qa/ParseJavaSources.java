import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;

/** Syntax-only check. This intentionally does not claim Android/Firebase type checking. */
public class ParseJavaSources {
    public static void main(String[] args) throws Exception {
        List<java.io.File> files = new ArrayList<>();
        try (var paths = Files.walk(Path.of(args[0]))) {
            paths.filter(p -> p.toString().endsWith(".java")).forEach(p -> files.add(p.toFile()));
        }
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, null, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                List.of("-proc:none", "-source", "17"), null, manager.getJavaFileObjectsFromFiles(files));
            task.parse();
            long errors = diagnostics.getDiagnostics().stream().filter(d -> d.getKind() == Diagnostic.Kind.ERROR).count();
            for (Diagnostic<?> diagnostic : diagnostics.getDiagnostics())
                if (diagnostic.getKind() == Diagnostic.Kind.ERROR) System.err.println(diagnostic);
            if (errors != 0) throw new AssertionError("Syntax errors: " + errors);
            System.out.println("Parsed " + files.size() + " Java sources; syntax errors=0; Android/Firebase type check not performed");
        }
    }
}
