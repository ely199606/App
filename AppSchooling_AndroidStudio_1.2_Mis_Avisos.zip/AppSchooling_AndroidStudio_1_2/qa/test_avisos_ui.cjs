const fs = require('fs'), vm = require('vm'), assert = require('assert');
const code = fs.readFileSync(require('path').join(__dirname, '../app/src/main/assets/www/avisos.js'), 'utf8');
const STORE = 'manzanin_avisos_v1';
function launch(storage = new Map(), native = null) {
  const listeners = {}, root = { hidden: false, addEventListener(type, fn) { (listeners[type] ||= []).push(fn); } };
  const context = { window: {}, document: root, URL, Date, console, localStorage: { getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value) } };
  if (native) context.window.AppSchoolingNative = native;
  vm.createContext(context); vm.runInContext(code, context);
  const api = context.window.AppSchoolingAvisos;
  let changes = 0; api.init(() => changes++);
  return { api, context, storage, listeners, get changes() { return changes; }, event(type, detail) { for (const fn of listeners[type] || []) fn({ detail }); }, click(action, id) { let prevented = false; const target = { dataset: { noticeAction: action, noticeId: id }, closest: () => target }; for (const fn of listeners.click || []) fn({ target, preventDefault() { prevented = true; } }); return prevented; }, choose(value) { for (const fn of listeners.change || []) fn({ target: { value, hasAttribute: name => name === 'data-notice-category' } }); } };
}
const notice = (id, bits = {}) => ({ schemaVersion: 1, id, revision: 1, category: 'general', title: 'Aviso ' + id, body: 'Mensaje para la familia.', publishedAt: '2026-11-02T15:00:00Z', eventAt: null, expiresAt: null, url: null, ...bits });

const storage = new Map([['appschooling_manzanin09', '{"profile":"UNCHANGED"}']]);
let app = launch(storage);
assert(app.api.render().includes('Todavía no tienes avisos'));
assert(app.api.render().includes('Conexión con la academia pendiente'));
assert(!app.api.render().includes('data-notice-action="permission"'));
assert.equal(app.api.unreadCount(), 0);
assert.equal(storage.has(STORE), false, 'opening an empty inbox does not fabricate records');
assert(app.api.receive(notice('a'))); assert.equal(app.api.unreadCount(), 1);
const afterFirst = storage.get(STORE), changes = app.changes;
assert.equal(app.api.receive(notice('a')), false); assert.equal(app.changes, changes);
assert.equal(storage.get(STORE), afterFirst, 'duplicate delivery does not rewrite stored state');
assert.equal(app.api.receive(notice('a', { revision: 0, title: 'Invalid old revision' })), false);
assert.equal(app.api.receive(notice('a', { title: 'Conflict at same revision' })), false);
assert(!app.api.render().includes('Conflict at same revision'));
assert(app.api.open('a')); assert.equal(app.api.unreadCount(), 0);
assert(app.api.render().includes('Leído')); assert(app.api.render().includes('Mensaje para la familia.'));
assert(app.api.receive(notice('a', { revision: 2, title: 'Fecha actualizada', category: 'evaluaciones' })));
assert.equal(app.api.unreadCount(), 1, 'a new revision must be consulted again');
assert(app.api.render().includes('Fecha actualizada'));
assert.equal(app.api.open('missing'), false);
assert(app.api.open('a')); assert.equal(app.api.unreadCount(), 0);

app = launch(storage);
assert.equal(app.api.unreadCount(), 0, 'read state survives closing and reopening');
assert(app.api.render().includes('Fecha actualizada'));
assert.equal(storage.get('appschooling_manzanin09'), '{"profile":"UNCHANGED"}');
assert(app.api.receive(JSON.stringify(notice('b', { category: 'examenes', publishedAt: '2026-11-03T15:00:00Z', readAt: '2026-11-03T15:00:01Z' }))));
assert.equal(app.api.unreadCount(), 1, 'remote payload cannot mark its own message read');
app.click('filter', 'pendientes'); assert(app.api.render().includes('Aviso b')); assert(!app.api.render().includes('Fecha actualizada'));
app.choose('evaluaciones'); assert(app.api.render().includes('No tienes avisos pendientes en esta categoría'));
app.choose('examenes'); assert(app.api.render().includes('Aviso b'));
app.click('all-read'); assert.equal(app.api.unreadCount(), 0);
app.click('filter', 'todos'); app.choose('todos');
assert(app.api.receive(notice('expired', { publishedAt: '2020-01-01T00:00:00Z', expiresAt: '2021-01-01T00:00:00Z' })));
assert.equal(app.api.unreadCount(), 0); assert(app.api.render().includes('Plazo finalizado'));

for (const url of ['javascript:alert(1)', 'http://example.com', 'data:text/html,test', 'https://user:password@example.com', 'https://example.com:8443/path']) assert.equal(app.api.receive(notice('unsafe', { url })), false);
for (const id of ['invalid id', 'üñicode', '<injected>', ' id', 'id/part', 'x'.repeat(129)]) assert.equal(app.api.receive(notice(id)), false);
for (const expiresAt of ['2026-11-01T15:00:00Z', '2026-11-02T15:00:00Z']) assert.equal(app.api.receive(notice('bad-expiry', { expiresAt })), false);
assert(app.api.receive(notice('good-port', { url: 'https://example.com:443/path' })));
assert.equal(app.api.receive(notice('invalid-calendar', { publishedAt: '2026-02-31T12:00:00Z' })), false);
assert.equal(app.api.receive(notice('oversized', { title: 'x'.repeat(121) })), false);
assert.equal(app.api.receive('{broken-json'), false);
assert.equal(app.api.receive({}), false);
assert.equal(app.api.receive(notice('unknown', { category: '__proto__' })), false);
assert(app.api.receive(notice('html', { title: '<img src=x onerror=alert(1)>', body: '<script>alert("x")</script>\nTexto normal', url: 'https://ayudamineduc.cl/?a=1&b=2' })));
app.api.open('html'); let html = app.api.render();
assert(!html.includes('<img src=x')); assert(!html.includes('<script>'));
assert(html.includes('&lt;script&gt;')); assert(html.includes('href="https://ayudamineduc.cl/?a=1&amp;b=2"'));
assert(html.includes('rel="noopener noreferrer"'));
assert(html.includes('data-notice-action="link" data-notice-id="html"'));
assert.equal(app.click('link', 'html'), false, 'without the native bridge the browser follows the normal anchor');

let nativeRecords = [notice('revision', { readAt: '2026-11-02T16:00:00Z' })];
const revisions = launch(new Map(), { getNotices: () => JSON.stringify(nativeRecords) });
assert.equal(revisions.api.unreadCount(), 0);
nativeRecords = [notice('revision', { revision: 2, title: 'Revisión dos' })]; revisions.api.syncNative();
assert.equal(revisions.api.unreadCount(), 1, 'higher native revision without its own readAt becomes unread');
nativeRecords = [notice('revision', { revision: 1, title: 'Viejo', readAt: '2026-11-02T17:00:00Z' })]; revisions.api.syncNative();
assert.equal(revisions.api.unreadCount(), 1, 'old native readAt cannot mark a newer revision read');
assert(revisions.api.render().includes('Revisión dos')); assert(!revisions.api.render().includes('Viejo'));
nativeRecords = [notice('revision', { revision: 2, readAt: '2026-11-02T17:00:00Z' })]; revisions.api.syncNative();
assert.equal(revisions.api.unreadCount(), 0, 'same native revision can import its own readAt');
nativeRecords = [notice('revision', { revision: 3, readAt: '2026-11-02T18:00:00Z' })]; revisions.api.syncNative();
assert.equal(revisions.api.unreadCount(), 0, 'higher native revision may already have been read natively');
assert(revisions.api.receive(notice('revision', { revision: 4, title: 'Revisión cuatro', readAt: '2026-11-02T19:00:00Z' })));
assert.equal(revisions.api.unreadCount(), 1, 'higher remote revision cannot supply readAt');
revisions.api.syncNative(); assert.equal(revisions.api.unreadCount(), 1, 'syncing old native revision cannot restore stale read state');

let state = { configured: false, permission: 'granted', enabled: false, registration: 'inactive' }, asked = 0, settings = 0;
const marked = [], linked = [], native = {
  getNoticeStatus: () => JSON.stringify(state),
  getNotices: () => JSON.stringify([notice('native', { readAt: '2026-11-02T16:00:00Z' })]),
  markNoticeRead: id => marked.push(id), openNoticeLink: id => linked.push(id), requestNoticePermission: () => { asked++; }, openNoticeSettings: () => { settings++; }
};
const nativeApp = launch(new Map(), native);
assert.equal(nativeApp.api.unreadCount(), 0, 'native read state is imported');
assert(nativeApp.api.render().includes('Conexión con la academia pendiente'));
state = { configured: true, permission: 'granted', enabled: false, registration: 'inactive' }; nativeApp.api.syncNative();
assert(nativeApp.api.render().includes('Activar avisos')); assert(!nativeApp.api.render().includes('Notificaciones activadas'));
nativeApp.click('permission'); assert.equal(asked, 1);
state.registration = 'pending'; nativeApp.api.syncNative(); assert(nativeApp.api.render().includes('Conectando los avisos'));
state.registration = 'error'; nativeApp.api.syncNative(); assert(nativeApp.api.render().includes('Volver a intentar'));
state.registration = 'ready'; state.enabled = true; nativeApp.api.syncNative(); assert(nativeApp.api.render().includes('Notificaciones activadas'));
state.permission = 'denied'; state.enabled = false; nativeApp.event('appschooling:notice-status'); assert(nativeApp.api.render().includes('Abrir ajustes'));
nativeApp.click('settings'); assert.equal(settings, 1);
nativeApp.event('appschooling:notice', notice('push')); assert.equal(nativeApp.api.unreadCount(), 1);
nativeApp.event('appschooling:notice-open', { id: 'push' }); assert.equal(nativeApp.api.unreadCount(), 0); assert.deepEqual(marked, ['push']);
assert(nativeApp.api.render().includes('Mensaje para la familia.'));
assert.equal(nativeApp.click('link', 'push'), true, 'native link routing prevents WebView navigation');
assert.deepEqual(linked, ['push'], 'native link receives only the persisted notice identifier');
nativeApp.api.init(() => {}); assert.equal(nativeApp.listeners.click.length, 1, 're-mounting never duplicates click listeners');

const failing = launch(); failing.context.localStorage.setItem = () => { throw Error('quota'); };
assert(failing.api.receive(notice('quota'))); assert(failing.api.render().includes('no permitió guardar'));
assert.equal(failing.api.unreadCount(), 1, 'storage failure retains the current session message');
console.log(JSON.stringify({ emptyInboxContainsNoSamples: true, connectionPendingIsHonest: true, deliveryDeduplicates: true, newRevisionBecomesUnread: true, oldRevisionCannotOverwriteReadState: true, sameNativeRevisionCanImportReadAt: true, readStatePersists: true, profilesUntouched: true, filtersAndCategoriesWork: true, expiredMessagesRemainHistorical: true, identifiersHttpsPortAndExpiryValidated: true, unsafeLinksAndHtmlHandled: true, nativeLinkRoutingAndBrowserFallback: true, nativeInboxImports: true, optInRequiredForRegistration: true, registrationStatesRendered: true, nativeTapOpensDetailAndMarksRead: true, listenersIdempotent: true, storageFailureVisible: true }));
